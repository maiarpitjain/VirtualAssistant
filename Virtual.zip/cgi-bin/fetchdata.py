import sqlite3

connection= sqlite3.connect('mydata.db')

crsr=connection.cursor()

crsr.execute("select * from arpit ")

ans= crsr.fetchall()

l=[]
for i in range(len(ans)):
	l.append(ans[i][0])
	
print(l)