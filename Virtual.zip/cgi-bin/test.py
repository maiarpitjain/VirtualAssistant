#!/usr/bin/python3.6
import pyttsx3
print("content-type: text/html")
print("location: http://18.140.226.122")
print()

speaker=pyttsx3.init()
speaker.say("Hello welcome to vincy")
speaker.runAndWait()
