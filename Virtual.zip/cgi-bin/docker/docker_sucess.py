#!/usr/bin/python3.6

import subprocess as sp
import cgi
import os
print("content-type: text/html")
print()

print("Successfully launched docker container")

