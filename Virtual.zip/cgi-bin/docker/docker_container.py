#!/usr/bin/python3.6

def save_in_database():
	pass
import subprocess as sp
import cgi
import os
print("content-type: text/html")


data=cgi.FieldStorage()
docker_name= data.getvalue('docker_name')

import random
random_num= random.randint(1000,9999)
a=sp.getoutput("sudo docker run -p {}:4200 -itd --name {}   -e SIAB_PASSWORD=redhat -e SIAB_USER={} -e SIAB_SSL=false -e SIAB_SUDO=true sspreitzer/shellinabox:latest".format(random_num,docker_name,docker_name))
#a=sp.getoutput("sudo ansible-playbook -i ../hosts playbooks/launch_container.py")
#b=sp.getoutput("sudo docker cp .bashrc {}:/root/.bashrc".format(docker_name))
#c=sp.getoutput("sudo docker restart {}".format(docker_name))

#print("location: http://18.140.226.122/cgi-bin/logs.py?docker_name={}".format(docker_name))
print("location: http://18.140.226.122/cgi-bin/docker/docker_sucess.py")
print()

#print("<input type='hidden' name='docker_name' value={}>".format(docker_name))
