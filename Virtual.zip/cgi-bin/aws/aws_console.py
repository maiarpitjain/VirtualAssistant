#!/usr/bin/python36

print("content-type: text/html")
print()
import subprocess as sp
import cgi,cgitb

cgitb.enable()

import time
time.sleep(40)
sp.getoutput("sudo scp -i rhel7Key ./sshd_config ec2-user@{}:/etc/ssh/")
sp.getoutput("sudo ssh -i rhel7Key ec2-user@{} sudo echo 'redhat\n' | passwd ec2-user --stdin".format(ip))

sp.getoutput("sudo scp -i rhel7Key ./epel.repo ec2-user@{}:/etc/yum.repos.d/")

