#!/usr/bin/python36

print("content-type: text/html")
print()
import subprocess as sp
import cgi,cgitb

cgitb.enable()


sp.getoutput("sudo ansible-playbook -i ../hosts ../playbooks/aws1.yml ")

#f=open('aws.txt','r')

#ip=f.readline()

#
f=open('aws.txt','r')

data=f.read()

data=data[1:-1]
data=data.split(", ")
ip=data[0].split(": ")
ip=ip[1]
f.close()
print("Your Ec2 ip is: {}".format(ip))



"""
import time
time.sleep(40)
sp.getoutput("scp -i rhel7Key.pem sshd_config  ec2-user@{}:/home/ec2-user".format(ip))
sp.getoutput("ssh -i rhel7Key.pem ec2-user@{} sudo cp sshd_config /etc/ssh/".format(ip))

sp.getoutput("sudo scp -i rhel7Key.pem ./epel.repo ec2-user@{}:/etc/yum.repos.d/")
sp.getoutput("sudo scp -i rhel7Key.pem ./sshd_config ec2-user@{}:/etc/ssh/")
sp.getoutput("sudo ssh -i rhel7Key.pem ec2-user@{} sudo echo 'redhat\n' | passwd ec2-user --stdin".format(ip))


print("successfully done")
"""

print("""
<form action="http://18.140.226.122">
	<button style="text-align: center;">Home</button>
</form>""")