#!/usr/bin/python3.6

def save_in_database():
	pass
import subprocess as sp
import cgi
import os
print("content-type: text/html")

data=cgi.FieldStorage()
number= data.getvalue('number')
msg= data.getvalue('msg')

f=open('hosts','r+')
f.write('[sms]\n')
f.write('127.0.0.1 ansible_user=centos ansible_password=Ahead@123\n')
f.close()

number=" '{}' ".format(number)

f=open('playbooks/data.yml','r+')
f.write('number: {}\n'.format(number))
f.write("msg: '{}'\n".format(msg))
f.close()

a=sp.getoutput("sudo ansible-playbook playbooks/message.yml")
print("location: http://18.140.226.122")
print()
