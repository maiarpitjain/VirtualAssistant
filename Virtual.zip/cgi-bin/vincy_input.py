#!/usr/bin/python3.6

def save_in_database():
	pass
import subprocess as sp
import cgi
import os
print("content-type: text/html")


data=cgi.FieldStorage()
query=data.getvalue('query')

if 'docker' and 'table' in query:
	print("location: http://18.140.226.122/cgi-bin/docker/docker_conf.py")
	print()
elif 'create' and 'hadoop' and 'cluster' in query:
	print("location: http://18.140.226.122/hadoop_ip.html")
	print()

elif 'launch' and 'instance' in query:
	print("location: http://18.140.226.122/cgi-bin/aws/launch_aws.py")
	print()
elif 'vincy' and 'send' and 'SMS' in query:
	print("location: http://18.140.226.122/sms.html")	
	print()

elif 'vincy' and 'send' and 'mail' in query:
	print("location: http://18.140.226.122/mail.html")	
	print()

elif 'launch' and 's3' in query:
	pass


else:
    print("location: http://18.140.226.122/notsupported.html")  
    print()



"""
import spacy
nlp=spacy.load('en_core_web_sm')
t=input()
text=nlp(t)
c=0
tags=[]
lemmas=[]
words=[]
for token in text:
        tags.append(token.tag_)
        lemmas.append(spacy.explain(token.tag_))
        words.append(token.text)
#print(tags,lemmas,words)    
if 'NN' in tags and ('Vincy' in words or 'vincy' in words):
        # index=words.index('launch')
        if 'RB' in tags and "n\'t":
            print("Ok I won't")
        if 'VB' in tags and ('launch' in words or 'run' in words):
                 if 'NN' in tags and ('docker' and 'container') in words :
                     print('launching container')
                 #else: print('no')
                 if 'NN' in tags and ('Amazon' and 'Instance') in words :
                    print('launching instance')
                 #else: print('no')
                 if 'NN' in tags and ('Amazon' and 'Bucket') in words or ('amazon' and 'bucket') in words:
                     print('launching bucket')
                 #else: print('no')


else : print('IDK')
"""
	
